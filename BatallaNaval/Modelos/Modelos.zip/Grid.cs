﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BatallaNaval.Modelos
{
    internal class Grid
    {
        public static List<List<Celda>> matrizCeldas { get; set; }


    }
}
